import funkin.data.Highscore;
import funkin.states.FreeplayState;

function onUpdate(elapsed:Float) {
	var songName:String = week_songs[FreeplayState.curSelect][0];
	infoText.text += '\n${Lang.str('misses')}: ${Highscore.getMisses(songName.toLowerCase(), 1)}';
}
