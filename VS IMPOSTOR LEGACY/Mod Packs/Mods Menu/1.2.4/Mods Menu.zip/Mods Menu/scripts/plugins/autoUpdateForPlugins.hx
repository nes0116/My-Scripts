import funkin.scripting.PluginsManager;
import sys.Http;
import sys.io.File;

var scripts:Array<Dynamic> = [
	{
		fileName: 'scriptLoader',
		url: 'https://raw.githubusercontent.com/nes0116/My-Scripts/refs/heads/main/VS%20IMPOSTOR%20LEGACY/Plugins/Script%20Loader/scriptLoader.hx'
	},
	{
		fileName: 'multipleScriptLoader',
		url: 'https://raw.githubusercontent.com/nes0116/My-Scripts/refs/heads/main/VS%20IMPOSTOR%20LEGACY/Plugins/Multiple%20Script%20Loader/multipleScriptLoader.hx'
	}
];

function onLoad() {
	if (StringTools.startsWith(script.name, 'autoUpdateForPlugins_')) {
		PluginsManager.loadedScripts.members.remove(script);
		script.destroy();
	}

	for (s in scripts) {
		var url:String = s.url;
		var http:Http = new Http(url);
		http.onData = function(data:String) {
			File.saveContent('content/scripts/plugins/${s.fileName}.hx', data);
		}
		http.request();
	}
}
