import funkin.objects.menu.AmongControls;
import funkin.scripting.PluginsManager;

function onLoad() {
	var bottomControls:AmongControls = new AmongControls([['arrow', 'select'], ['enter', 'conf'], ['tab', 'open_mods_menu']], false);
	add(bottomControls);
}

function onUpdate(elapsed:Float) {
	if (!lockMovement) {
		if (FlxG.keys.justPressed.TAB) {
			FlxG.switchState(new ScriptedState('ModsMenuState'));
		}
	}
}
