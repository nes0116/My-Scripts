import Reflect;
import String;
import funkin.FunkinAssets;
import funkin.Mods;
import funkin.api.DiscordClient;
import funkin.backend.Logger;
import funkin.data.Defines;
import funkin.objects.menu.AmongControls;
import funkin.objects.menu.ScrollBar;
import funkin.states.MainMenuState;
import sys.Http;
import sys.io.File;

final version:String = '1.2.0';

//

var modList:Array<String> = [];
var missingPlugins:Array<Dynamic> = [];
var grpMods:FlxSpriteGroup = new FlxSpriteGroup();

//

var bottomControls:AmongControls;
var scrollBar:ScrollBar;
var deacBg:FlxSprite;
var descTxt:FlxText;

//

var elapsedTime:Float = 0;
var curMod:Int = 0;
var canControl:Bool = true;

function onCreate() {
	modList = Mods.all;

	DiscordClient.changePresence("Mods Menu");

	persistentUpdate = true;

	var starBG = new FlxBackdrop(Paths.image('menu/common/starBG'));
	add(starBG);
	starBG.velocity.x -= 7;

	var starFG = new FlxBackdrop(Paths.image('menu/common/starFG'));
	add(starFG);
	starFG.velocity.x = -15;

	add(grpMods);

	for (i => mod in modList) {
		var text:FlxText = new FlxText(0, 0, 0, mod);
		text.setFormat(Paths.font("jp.ttf"), 32, FlxColor.WHITE, FlxTextAlign.LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		text.ID = i;
		grpMods.add(text);
	}

	bottomControls = new AmongControls([], false);
	add(bottomControls);

	refreshControls();

	var text:FlxText = new FlxText(10, 60, 0, 'Manage Mods');
	text.setFormat(Paths.font("vcr.ttf", false), 40, FlxColor.WHITE, FlxTextAlign.LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
	add(text);

	var verText:FlxText = new FlxText(10, 60, 0, version);
	verText.setFormat(Paths.font("vcr.ttf", false), 16, FlxColor.WHITE, FlxTextAlign.LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
	verText.x = text.x + text.width + 8;
	verText.y = text.y + text.height - verText.height - 8;
	add(verText);

	var upperLine:FlxSprite = new FlxSprite().makeGraphic(FlxG.width * 2, 2);
	upperLine.screenCenter(0x01);
	upperLine.y = 50;
	add(upperLine);

	var lowerLine:FlxSprite = new FlxSprite().makeGraphic(FlxG.width * 2, 2);
	lowerLine.screenCenter(0x01);
	lowerLine.y = FlxG.height - lowerLine.height - 50;
	add(lowerLine);

	scrollBar = new ScrollBar(0, 0, 10, FlxG.height - 300, 0x80ffffff);
	scrollBar.x = FlxG.width - scrollBar.width - 10;
	scrollBar.y = FlxG.height / 2 - scrollBar.height / 2;
	scrollBar.progress = 0;
	scrollBar.setMetrics(1, modList.length - 1);
	scrollBar.onScroll.add((scroll:Float, prevScroll:Float) -> {
		if (!scrollBar.draggingThumb)
			return;

		if (Std.int(scroll * (modList.length - 1)) != Std.int(prevScroll * (modList.length - 1))) {
			changeMod(Std.int(scroll * (modList.length - 1)), false);
		}
	});
	add(scrollBar);

	deacBg = new FlxSprite().makeGraphic(1, 1, FlxColor.BLACK);
	deacBg.alpha = 0.25;
	add(deacBg);

	descTxt = new FlxText(0, 0, FlxG.width, '');
	descTxt.setFormat(Paths.font("jp.ttf", false), 24, FlxColor.WHITE, FlxTextAlign.CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
	add(descTxt);

	changeMod(0, true);
}

function isEnabled(mod:String) {
	return Mods.enabled.contains(mod);
}

var holdingMod:String = '';

function onUpdate(elapsed:Float) {
	elapsedTime += elapsed;

	if (FlxG.sound.music.volume > 0.45)
		FlxG.sound.music.volume -= 0.5 * elapsed;

	if (canControl) {
		if (controls.BACK) {
			canControl = false;
			FlxG.switchState(new MainMenuState());
			FlxG.sound.play(Paths.sound('cancelMenu'), 0.7);
		}

		if (controls.UI_UP_P) {
			changeMod(-1, true);
		}

		if (controls.UI_DOWN_P) {
			changeMod(1, true);
		}

		if (FlxG.mouse.wheel != 0) {
			changeMod(-FlxG.mouse.wheel, true);
		}

		if (controls.ACCEPT) {
			toggleMod(grpMods.members[curMod].text);
		}

		if (controls.RESET) {
			if (Mods.disabled.length > 0) {
				for (mod in Mods.disabled) {
					Mods.enabled.push(mod);
				}

				Mods.disabled = [];

				Mods.writeModList();
				refreshControls();

				FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
			} else {
				for (mod in Mods.enabled) {
					if (mod != 'Mods Menu')
						Mods.disabled.push(mod);
				}

				Mods.enabled = ['Mods Menu'];

				Mods.writeModList();
				refreshControls();

				FlxG.sound.play(Paths.sound('cancelMenu'), 0.7);
			}
		}

		if (FlxG.keys.justPressed.CONTROL) {
			if (holdingMod == '') {
				holdingMod = modList[curMod];
				FlxG.sound.play(Paths.sound('cancelMenu'), 0.7);
			} else {
				holdingMod = '';
				FlxG.sound.play(Paths.sound('cancelMenu'), 0.7);
				Mods.writeModList();
			}
		}

		if (FlxG.keys.justPressed.TAB) {
			CoolUtil.openFolder('content/', true);
		}

		if (missingPlugins.length > 0) {
			if (FlxG.keys.justPressed.ALT) {
				var downloadSuccess:Bool = false;

				for (plugin in missingPlugins) {
					var url:String = plugin.url;
					if (url.length > 0) {
						if (StringTools.startsWith(url, 'https://raw.github')) {
							var http:Http = new Http(url);
							http.onData = function(data:String) {
								File.saveContent('content/scripts/plugins/${plugin.name}.hx', data);
								Logger.log('[MODS MENU STATE] ${plugin.name} has been successfully downloaded!', 3, true);
								downloadSuccess = true;
							}
							http.onError = function(error:String) {
								FlxG.sound.play(Paths.sound('cancelMenu'), 0.7);
							}
							http.request();
						} else {
							CoolUtil.browserLoad(url);
						}
					}
				}

				if (downloadSuccess) {
					FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
					changeMod(0, true);
				}
			}
		}
	}

	for (text in grpMods) {
		var goalX:Float = 150 + 67 * (text.ID - curMod) + (holdingMod == text.text ? 25 : 0);
		var goalY:Float = FlxG.height / 2 - text.height / 2 + 67 * (text.ID - curMod);

		text.x = elapsedTime < 0.1 ? goalX : FlxMath.lerp(goalX, text.x, Math.exp(-elapsed * 15));
		text.y = elapsedTime < 0.1 ? goalY : FlxMath.lerp(goalY, text.y, Math.exp(-elapsed * 15));
		text.alpha = 1 - (text.ID == curMod ? 0 : 0.3) - 0.1 * Math.abs(text.ID - curMod);

		if (canControl) {
			if (FlxG.mouse.overlaps(text) && FlxG.mouse.justPressed) {
				if (curMod == text.ID) {
					toggleMod(text.text);
					return;
				}

				changeMod(text.ID, false);
			}
		}

		text.color = holdingMod == text.text ? FlxColor.CYAN : isEnabled(text.text) ? FlxColor.LIME : FlxColor.WHITE;
	}

	deacBg.setGraphicSize(descTxt.width + 10, descTxt.height + 10);
	deacBg.updateHitbox();
	deacBg.x = descTxt.x - 5;
	deacBg.y = descTxt.y - 5;
}

function toggleMod(mod:String) {
	if (mod == 'Mods Menu') {
		FlxG.sound.play(Paths.sound('locked'), 0.7);

		if (ClientPrefs.flashing) {
			FlxG.camera.shake(0.005, 0.25);
		}

		return;
	}

	if (isEnabled(mod)) {
		Mods.enabled.remove(mod, true);
		Mods.disabled.push(mod);
		FlxG.sound.play(Paths.sound('cancelMenu'), 0.7);
	} else {
		Mods.disabled.remove(mod, true);
		Mods.enabled.push(mod);
		FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
	}

	refreshControls();
	Mods.writeModList();
}

function changeMod(value:Int, wrap:Bool) {
	var oldCurMod:Int = curMod;
	var newCurMod:Int = FlxMath.wrap(wrap ? curMod + value : value, 0, modList.length - 1);
	var newMod:String = grpMods.members[newCurMod].text;
	curMod = newCurMod;

	if (holdingMod.length > 0) {
		var temp:String = modList[oldCurMod];
		modList[oldCurMod] = modList[curMod];
		modList[curMod] = temp;

		grpMods.members[oldCurMod].text = modList[oldCurMod];
		grpMods.members[curMod].text = modList[curMod];

		Mods.all = modList;
		Mods.writeModList();
	}

	var pack:Dynamic = Mods.getPack(grpMods.members[curMod].text);
	if (pack != null) {
		if (pack.description != null)
			if (Std.isOfType(pack.description, String)) {
				descTxt.text = pack.description;
			} else {
				var str:String = Reflect.getProperty(pack.description, ClientPrefs.language);
				descTxt.text = str == null ? pack.description.english == null ? '' : pack.description.english : str;
			}
		else
			descTxt.text = '';

		missingPlugins = [];
		if (pack.requiredPlugins != null) {
			for (plugin in pack.requiredPlugins) {
				if (!FunkinAssets.exists(Paths.getPath('scripts/plugins/${plugin.name}.hx', null, PathsTestMode.LOOSE)))
					if (!missingPlugins.contains(plugin))
						missingPlugins.push(plugin);
			}

			if (missingPlugins.length > 0) {
				var hasUrl:Bool = false;

				descTxt.text = '${Lang.str('plugin_missing')}\n';
				for (plugin in missingPlugins) {
					descTxt.text += '${plugin.name}${(missingPlugins.indexOf(plugin) != missingPlugins.length - 1 ? ', ' : '')}';

					if (plugin.url.length > 0)
						hasUrl = true;
				}

				if (hasUrl) {
					descTxt.text += '\n${Lang.str('plugin_missing_download')}';
				}

				descTxt.font = Paths.font('jpBold.ttf');
				descTxt.color = FlxColor.RED;
			} else {
				descTxt.color = FlxColor.WHITE;
				descTxt.font = Paths.font('jp.ttf');
			}
		}

		descTxt.y = FlxG.height / 1.25 - descTxt.height / 2;
	} else {
		descTxt.text = '';
		descTxt.color = FlxColor.WHITE;
		descTxt.font = Paths.font('jp.ttf');
	}

	scrollBar.progress = curMod / (modList.length - 1);

	FlxG.sound.play(Paths.sound('scrollMenu'), 0.7);
}

function refreshControls() {
	if (Mods.disabled.length > 0) {
		bottomControls.inputs = [
			['arrow', 'select'],
			['enter', 'switch_mod'],
			['esc', 'back'],
			['tab', 'open_content_folder'],
			['reset', 'enable_all']
		];
		bottomControls.refreshBar();
	} else {
		bottomControls.inputs = [
			['arrow', 'select'],
			['enter', 'switch_mod'],
			['esc', 'back'],
			['tab', 'open_content_folder'],
			['reset', 'disable_all']
		];
		bottomControls.refreshBar();
	}
}

function onDestroy() {}
