function onLoad() {
	videoCutscene('week3/danger', false);
}

public var blackTimeScale:Float = 1;
public var blackTimeScaleLerp:Float = 1;
var ragdoledSound:FunkinSound;
var footstepSound:FunkinSound;

function onCreatePost() {
	snapCamToPos(1634.05, -54.3);
	camSpecialThing([1634.05, -54.3], [1734.05, -54.3], 0.3);

	ragdoledSound = FunkinSound.load(Paths.sound('ragdol', null, PathsTestMode.LOOSE));
	ragdoledSound.looped = true;
	ragdoledSound.pitch = 1.5;
	ragdoledSound.volume = 0;
	ragdoledSound.play();

	footstepSound = FunkinSound.load(Paths.sound('footstep', null, PathsTestMode.LOOSE));
	footstepSound.volume = 0;

	dad.origin.set(729, 1187.5);
	dadLegs.origin.set(729, 1187.5);
}

function onBeatHit() {
	switch (curBeat) {
		case 1:
			camSpecialThing([1634.05, -54.3], [1634.05, -54.3], 0.3);
		case 64:
			camSpecialThing([800, 150], [1200, 150], 0.4);
		case 96:
			camSpecialThing([700, 150], [1200, 150], 0.6);
		case 128:
			camSpecialThing([800, 150], [1200, 150], 0.4);
		case 144:
			camSpecialThing([800, 150], [1200, 150], 0.5);
		case 152:
			camSpecialThing([800, 150], [1200, 150], 0.6);
		case 154:
			camSpecialThing([600, 150], [600, 150], 0.6);
		case 156:
			camSpecialThing([450, 150], [450, 150], 0.8);
		case 158:
			game.camGame.shake(0.01, (Conductor.stepCrotchet / 1000) * 4);
			camSpecialThing([450, 150], [450, 150], 0.6);
		case 160:
			camSpecialThing([800, 150], [1200, 150], 0.4);
		case 192:
			camSpecialThing([700, 150], [1200, 150], 0.6);
		case 256:
			camSpecialThing([800, 150], [1200, 150], 0.4);
		case 288:
			camSpecialThing([700, 150], [1200, 150], 0.6);
		case 320:
			camSpecialThing([1634.05, -54.3], [1634.05, -54.3], 0.3);
		case 384:
			camSpecialThing([700, 150], [1200, 150], 0.6);
	}
}

var dadState:Int = 0;

function onSectionHit() {
	dadState = FlxG.random.int(0, 4);
}

function onUpdatePost(elapsed:Float) {
	var dadSpeed:Float = 0;
	var isMad:Bool = dadLegs.animation.curAnim.name == 'legs-mad';
	switch (dadState) {
		case 0:
			dadSpeed = -100;
			blackTimeScale = 0.75;
		case 1:
			dadSpeed = 100;
		case 2:
			dadSpeed = isMad ? 5000 : 1000;
			blackTimeScale = isMad ? 3 : 1.5;
		case 3:
			dadSpeed = isMad ? 10000 : 1000;
			blackTimeScale = isMad ? 5 : 2.5;
		case 4:
			dadSpeed = -1000;
			blackTimeScale = 0.5;
	}

	if (dad.angle > 10) {
		FlxG.camera.shake(0.01, 0.1);
		ragdoledSound.volume = 0.75;
		opponentStrums.autoPlayed = false;
		audio?.volume = 0;
		audio?.inst?.volume = 1;
	} else {
		ragdoledSound.volume = 0;
		opponentStrums.autoPlayed = true;
		audio?.volume = 1;
	}

	footstepSound.volume = FlxMath.remapToRange(dad.x - boyfriend.x, -5555, -1111, 0, 0.4);
	if (prevLegsFrame != dadLegs.animation.curAnim.curFrame) {
		if (dadLegs.animation.curAnim.curFrame == 0 || dadLegs.animation.curAnim.curFrame == 8) {
			ragdoledSound.pitch = FlxG.random.float(0.6, 1.4);
			footstepSound.play(true);
		}
	}

	blackTimeScaleLerp = FlxMath.lerp(blackTimeScale, blackTimeScaleLerp, Math.exp(-elapsed * 3));

	if (dad.x < 500) {
		dad.velocity.x = FlxMath.lerp(dadSpeed, dad.velocity.x, Math.exp(-elapsed * 3));
		dad.angle = FlxMath.lerp(0, dad.angle, Math.exp(-elapsed * 10));
	} else {
		dad.angle = 36000;
		dad.velocity.x = -5000;
		dad.velocity.x = FlxMath.lerp(0, dad.velocity.x, Math.exp(-elapsed * 3));
	}
}

function goodNoteHitPre(note) {
	if (ragdoledSound.volume != 0) {
		note.animSuffix = 'miss';
		FlxG.sound.play(Paths.soundRandom('missnote', 1, 3), FlxG.random.float(0.1, 0.2));
	}
}

function onPause() {
	ragdoledSound?.pause();
	footstepSound?.pause();
}

function onResume() {
	ragdoledSound?.resume();
	footstepSound?.resume();
}
