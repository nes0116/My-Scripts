import funkin.Mods;
import funkin.scripting.PluginsManager;
import sys.Http;
import sys.io.File;

function onLoad() {
	var scripts:Array<Dynamic> = [];

	if (StringTools.startsWith(script.name, 'autoUpdateForPlugins_')) {
		PluginsManager.loadedScripts.members.remove(script);
		script.destroy();
	}

	for (p in Mods.getPack(script.modFolder).requiredPlugins) {
		scripts.push({fileName: p.name, url: p.url});
	}

	for (s in scripts) {
		var url:String = s.url;
		var http:Http = new Http(url);
		http.onData = function(data:String) {
			File.saveContent('content/scripts/plugins/${s.fileName}.hx', data);
		}
		http.request();
	}
}
