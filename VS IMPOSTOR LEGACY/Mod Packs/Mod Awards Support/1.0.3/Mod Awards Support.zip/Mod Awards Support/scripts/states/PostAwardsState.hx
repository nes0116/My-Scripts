import flixel.FlxG;
import flixel.FlxObject;
import flixel.FlxSprite;
import flixel.addons.display.FlxBackdrop;
import flixel.addons.text.FlxTypeText;
import flixel.group.FlxGroup.FlxTypedGroup;
import flixel.math.FlxRandom;
import flixel.text.FlxText;
import flixel.util.FlxGradient;
import flixel.util.FlxSpriteUtil;
import flixel.util.FlxStringUtil;
import flixel.util.FlxTimer;
import funkin.FunkinAssets;
import funkin.Mods;
import funkin.api.DiscordClient;
import funkin.data.Highscore;
import funkin.game.shaders.ColorSwap;
import funkin.input.TurboControl;
import funkin.input.TurboControlGroup;
import funkin.states.MainMenuState;
import funkin.utils.ProgressionUtil;

using Lambda;

var camUpper:FlxCamera;
var starsBG:FlxBackdrop;
var starsFG:FlxBackdrop;
var backButton:FlxSprite;
var camFollow:FlxObject;
var lockMovement:Bool = false;
var achievements:Array<Achievement> = [];
var nameText:FlxText;
var infoText:FlxText;
var completionText:FlxText;
var averageAccuracyText:FlxText;
var playTimeText:FlxText;
var achArray:Array<FlxSprite>;
var curSel:Int = 0;
var hoveredMouseSel:Int = -1;
var mouseControlActive:Bool = true;
var completion = ProgressionUtil.calculateCompletion();
var turboGroup:TurboControlGroup;
var controlDOWN:TurboControl = TurboControl.fromControl('ui_down');
var controlUP:TurboControl = TurboControl.fromControl('ui_up');
var controlLEFT:TurboControl = TurboControl.fromControl('ui_left');
var controlRIGHT:TurboControl = TurboControl.fromControl('ui_right');
final columnsPerRow:Int = 7;

function loadAchievements() {
	achievements = [];

	var path = 'assets/data/awards.json';
	if (FunkinAssets.exists(path)) {
		json = FunkinAssets.parseJson(FunkinAssets.getContent(path));
		for (award in json.awards) {
			achievements.push({
				name: award.id,
				icon: award.img,
				displayName: award.name,
				displayHint: award.hint,
				displayDesc: award.desc,
				hidden: award.hidden
			});
		}
	}

	for (mod in Mods.enabled) {
		var path = 'content/$mod/data/awards.json';
		if (FunkinAssets.exists(path))
			json = FunkinAssets.parseJson(FunkinAssets.getContent(path));
		else
			continue;
		for (award in json.awards) {
			achievements.push({
				name: award.id,
				icon: award.img,
				displayName: award.name,
				displayHint: award.hint,
				displayDesc: award.desc,
				hidden: award.hidden
			});
		}
	}

	if (achievements.length <= 0) {
		achievements = [
			{
				name: 'week1',
				hidden: false
			},
			{
				name: 'week2',
				hidden: false
			},
			{
				name: 'week3',
				hidden: false
			}
		];
	}
}

function onCreate() {
	var ext:String = 'menu/common';

	camUpper = new FlxCamera();
	camUpper.bgColor = 0x0;
	FlxG.cameras.add(camUpper, false);

	starsBG = new FlxBackdrop(Paths.image('$ext/starBG'));
	starsBG.scrollFactor.set();
	starsBG.velocity.x = -4.5;
	starsBG.zIndex = -2;
	add(starsBG);

	starsFG = new FlxBackdrop(Paths.image('$ext/starFG'));
	starsFG.scrollFactor.set();
	starsFG.velocity.x = -9;
	starsFG.zIndex = -1;
	add(starsFG);

	backButton = new FlxSprite(12, 8).loadGraphic(Paths.image('$ext/menuBack'));
	backButton.scrollFactor.set();
	add(backButton);

	add(turboGroup = new TurboControlGroup());
	turboGroup.add(controlDOWN);
	turboGroup.add(controlUP);
	turboGroup.add(controlLEFT);
	turboGroup.add(controlRIGHT);

	FlxG.mouse.visible = true;

	backButton.setPosition(15, 15);
	add(backButton).revive();

	loadAchievements();

	FlxG.camera.maxScrollY = FlxG.height;

	achArray = [];
	var xAdd = 0;
	var yAdd = 0;
	for (i in 0...achievements.length) {
		final unlocked = ownAchievement(i);
		var iconName:String = achievements[i].icon ?? GameFlags.getAchievementIcon(achievements[i].name);
		if (!unlocked || !Paths.fileExists('images/awards/$iconName.png'))
			iconName = 'blank';
		var img:FlxSprite = new FlxSprite(85 + (xAdd * 165), 30 + (yAdd * 130)).loadGraphic(Paths.image('awards/$iconName'));
		img.setGraphicSize(120, 120);
		img.updateHitbox();
		img.ID = i;
		add(img);
		achArray.push(img);

		FlxG.camera.maxScrollY = Math.max(img.y + img.height + FlxG.height / 2.75, FlxG.camera.maxScrollY);

		xAdd += 1;
		if (xAdd >= columnsPerRow) {
			xAdd = 0;
			yAdd += 1;
		}
	}
	var unlockedAwards:Int = achievements.count((award) -> GameFlags.hasAchievement(award.name));

	var gradient:FlxSprite = FlxGradient.createGradientFlxSprite(FlxG.width, FlxG.height / 4, [FlxColor.BLACK, FlxColor.TRANSPARENT], 1, 270);
	gradient.scrollFactor.set();
	gradient.y = FlxG.height - gradient.height;
	add(gradient);

	DiscordClient.changePresence('Awards Menu (${unlockedAwards}/${achievements.length})', null); // Updating Discord Rich Presence

	var localizedAwardsFont:String = Lang.getFont('vcr.ttf');
	var isVcrFont:Bool = StringTools.startsWith((localizedAwardsFont ?? 'vcr.ttf').toLowerCase(), 'vcr');

	nameText = new FlxText(0, 540, 1280, 'name', 40);
	infoText = new FlxText(0, isVcrFont ? 580 : 600, 1280, 'bio', 25);
	completionText = new FlxText(10, 0, 0, '', 25);
	averageAccuracyText = new FlxText(10, 0, 0, '', 25);
	playTimeText = new FlxText(10, 0, 0, '', 25);
	var howManyText:FlxText = new FlxText(0, 700, 1250, 'ball', 25);
	howManyText.text = StringTools.replace(Lang.str('awards_counter'), '@', '${unlockedAwards}/${achievements.length}');
	for (txt in [
		nameText,
		infoText,
		completionText,
		averageAccuracyText,
		playTimeText,
		howManyText
	]) {
		txt.setFormat(Paths.font("vcr.ttf"), txt.size, 0xFFFFFF, FlxTextAlign.CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		txt.borderSize = 2.5;
		txt.antialiasing = ClientPrefs.globalAntialiasing;
		txt.scrollFactor.set();
		add(txt);
	}
	completionText.alignment = 'left';
	averageAccuracyText.alignment = 'left';
	playTimeText.alignment = 'left';
	playTimeText.y = (FlxG.height - playTimeText.height) - 9;
	averageAccuracyText.y = playTimeText.y - averageAccuracyText.height;
	completionText.y = averageAccuracyText.y - completionText.height;
	howManyText.alignment = 'right';
	howManyText.y = (FlxG.height - howManyText.height) - 9;
	if (unlockedAwards >= achievements.length)
		howManyText.color = 0xFFFFE066;

	camFollow = new FlxObject(FlxG.width / 2, FlxG.height / 2, 1, 1);
	add(camFollow);

	FlxG.camera.minScrollY = 0;
	FlxG.camera.follow(camFollow, null, 0.15);

	refreshCompletionText();
	refreshaverageAccuracyText();
	refreshPlayTimeText();
	refreshSelection();
}

function exit() {
	if (lockMovement)
		return;

	lockMovement = true;

	FlxG.sound.play(Paths.sound('cancelMenu'), .6);
	FlxG.switchState(new MainMenuState());
}

function refreshCompletionText():Void {
	var completionLabel:String = Lang.str('game_completion', 'Completion');
	var completionValue:String = '${Math.floor(completion.percent)}%';
	completionText.text = Lang.hasSpecial('rightToLeft') ? '$completionValue :$completionLabel' : '$completionLabel: $completionValue';
	completionText.color = completion.percent >= 100 ? 0xFFFFE066 : FlxColor.WHITE;
}

function refreshaverageAccuracyText() {
	var totalAccuracy:Float = 0;
	var songsCount:Int = 0;
	for (song in Highscore.songRating.keys()) {
		totalAccuracy += Highscore.songRating.get(song);
		songsCount++;
	}
	averageAccuracyText.text = '${Lang.str('game_averageaccuracy')}: ${FlxMath.bound(Math.round(totalAccuracy / songsCount * 10000) / 100, 0, 100) + '%'}';
}

function refreshPlayTimeText():Void {
	var totalSeconds:Int = Math.floor(ClientPrefs.totalPlayTime);
	var hours:Int = Math.floor(totalSeconds / 3600);
	var minutes:Int = Math.floor((totalSeconds % 3600) / 60);
	var seconds:Int = totalSeconds % 60;
	var playTimeLabel:String = Lang.str('game_totalplaytime', 'Total Play Time');
	var playTimeValue:String = '${hours}h ${minutes}m ${seconds}s';
	playTimeText.text = Lang.hasSpecial('rightToLeft') ? '$playTimeValue :$playTimeLabel' : '$playTimeLabel: $playTimeValue';
}

function refreshSelection() {
	completion = ProgressionUtil.calculateCompletion();
	refreshCompletionText();
	refreshIconAlphas();

	final selected = achievements[curSel];
	final unlocked = ownAchievement(curSel);
	nameText.color = unlocked ? 0xFFFFE066 : FlxColor.WHITE;

	if (selected.hidden && !unlocked) {
		nameText.text = '???';
		infoText.text = Lang.str('AWARDS_SECRET');
	} else {
		nameText.text = Lang.str('AWARDNAME_${selected.name}', selected.displayName ?? selected.name);

		final awardDesc = Lang.str('AWARDBIO_${selected.name}', selected.displayDesc ?? '');
		var awardHint = Lang.str('AWARDHINT_${selected.name}', selected.displayHint ?? '');
		if (awardHint == null || StringTools.trim(awardHint).length == 0)
			awardHint = selected.displayHint;
		if (awardHint == null || StringTools.trim(awardHint).length == 0)
			awardHint = awardDesc;

		infoText.text = unlocked ? awardDesc : awardHint;
	}
}

function ownAchievement(i:Int):Bool {
	return GameFlags.hasAchievement(achievements[i].name);
}

function refreshIconAlphas():Void {
	for (icon in achArray) {
		icon.alpha = 0.6;
		if (icon.ID == hoveredMouseSel && icon.ID != curSel) {
			icon.alpha = 0.8;
		}
		if (icon.ID == curSel) {
			icon.alpha = 1;
		}
	}
}

function changeColumn(by:Int = 0):Void {
	final curRow:Int = Std.int(curSel / columnsPerRow);
	final maxColumn:Int = FlxMath.minInt(achievements.length - curRow * columnsPerRow, columnsPerRow);

	if (maxColumn <= 1)
		return;

	curSel = (FlxMath.wrap(curSel % columnsPerRow + by, 0, maxColumn - 1) + curRow * columnsPerRow);

	if (by != 0)
		FlxG.sound.play(Paths.sound('scrollMenu'));

	refreshSelection();
}

function changeRow(by:Int = 0):Void {
	final curColumn:Int = (curSel % columnsPerRow);
	final curRow:Int = Std.int(curSel / columnsPerRow);
	final maxRow:Int = (Math.floor(achievements.length / columnsPerRow) + (achievements.length % columnsPerRow <= curColumn ? 0 : 1));

	if (maxRow <= 1)
		return;

	final newRow = FlxMath.wrap(curRow + by, 0, maxRow - 1);

	curSel = (curColumn + newRow * columnsPerRow);

	if (by != 0)
		FlxG.sound.play(Paths.sound('scrollMenu'));

	refreshSelection();
}

function theMouseShit():Void {
	var newHovered:Int = -1;
	for (icon in achArray) {
		if (!FlxG.mouse.overlaps(icon))
			continue;
		newHovered = icon.ID;
		if (FlxG.mouse.justPressed) {
			if (curSel != icon.ID) {
				curSel = icon.ID;
				refreshSelection();
			}
			FlxG.sound.play(Paths.sound('scrollMenu'));
		}

		break;
	}

	if (hoveredMouseSel != newHovered) {
		hoveredMouseSel = newHovered;
		refreshIconAlphas();
	}
}

function onUpdate(elapsed:Float) {
	if (!lockMovement && (controls.BACK || (backButton.alive && FlxG.mouse.justPressed && FlxG.mouse.overlaps(backButton, camUpper))))
		exit();

	refreshPlayTimeText();

	if (FlxG.mouse.justMoved) {
		mouseControlActive = true;
	}

	if (controlUP.PRESSED || controlDOWN.PRESSED || controlLEFT.PRESSED || controlRIGHT.PRESSED || controls.BACK) {
		mouseControlActive = false;
	}

	if (mouseControlActive) {
		theMouseShit();
	} else if (hoveredMouseSel != -1) {
		hoveredMouseSel = -1;
		refreshIconAlphas();
	}

	for (a in achArray) {
		if (a.ID == curSel) {
			camFollow.y = a.y + a.height / 2;
		}
	}

	if (controlUP.PRESSED)
		changeRow(-1);
	if (controlDOWN.PRESSED)
		changeRow(1);
	if (controlLEFT.PRESSED)
		changeColumn(-1);
	if (controlRIGHT.PRESSED)
		changeColumn(1);
}
