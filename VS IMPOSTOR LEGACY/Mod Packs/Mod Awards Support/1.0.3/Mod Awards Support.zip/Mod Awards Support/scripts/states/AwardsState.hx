import flixel.addons.transition.FlxTransitionableState;

function onLoad() {
	FlxTransitionableState.skipNextTransIn = true;
	FlxG.switchState(new ScriptedState('PostAwardsState'));
}
